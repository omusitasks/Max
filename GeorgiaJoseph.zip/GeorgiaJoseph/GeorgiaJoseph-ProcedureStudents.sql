CREATE PROCEDURE AddStudent
    @SIN VARCHAR(255),
    @first_name VARCHAR(255),
    @last_name VARCHAR(255),
    @email VARCHAR(255),
    @phone_number VARCHAR(255),
    @startdate DATE,
    @program_id INT
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO students (SIN, first_name, last_name, email, phone_number, startdate, program_id)
    VALUES (@SIN, @first_name, @last_name, @email, @phone_number, @startdate, @program_id);
END;
