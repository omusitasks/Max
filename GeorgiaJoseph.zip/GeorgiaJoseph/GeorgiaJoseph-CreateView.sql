CREATE VIEW stuproview AS
SELECT s.first_name, s.last_name, s.email, s.phone_number, s.startdate, p.program_name, p.program_email, p.program_cname
FROM students s
JOIN programs p ON s.program_id = p.id;


