CREATE INDEX idx_programs_name_contact_email ON programs (program_name, program_cname, program_email);
