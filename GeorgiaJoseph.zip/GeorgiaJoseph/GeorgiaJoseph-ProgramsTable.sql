CREATE TABLE programs (
    id INT IDENTITY(1,1) PRIMARY KEY,
    program_code INT NOT NULL,
    program_name VARCHAR(255) UNIQUE NOT NULL,
    program_email VARCHAR(255) NOT NULL,
    program_cname VARCHAR(255) NOT NULL,
    startdate DATE
);
