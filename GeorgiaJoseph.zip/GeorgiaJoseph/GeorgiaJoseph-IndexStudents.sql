CREATE INDEX idx_students_names_email ON students (first_name, last_name, email);
