CREATE PROCEDURE AddProgram
    @program_code INT,
    @program_name VARCHAR(255),
    @program_email VARCHAR(255),
    @program_cname VARCHAR(255),
    @startdate DATE
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO programs (program_code, program_name, program_email, program_cname, startdate)
    VALUES (@program_code, @program_name, @program_email, @program_cname, @startdate);
END;
