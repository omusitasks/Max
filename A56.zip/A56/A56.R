# Load necessary libraries
library(ggplot2)
library(dplyr)

# Data for glucose tolerance test
glucose_data <- data.frame(
  Time = rep(c(0, 30, 60, 90, 120), each = 3),
  Patient = rep(c("A", "B", "C"), times = 5),
  A505 = c(0.406, 0.366, 0.421, 0.492, 0.565, 0.745, 0.598, 0.864, 0.936, 0.49, 0.449, 0.765, 0.411, 0.446, 0.643)
)

# Plot glucose tolerance curves
ggplot(glucose_data, aes(x = Time, y = A505, color = Patient, group = Patient)) +
  geom_line() +
  geom_point() +
  labs(title = "Glucose Tolerance Curves", x = "Time (minutes)", y = "Absorbance at 505 nm") +
  theme_minimal()

# Data for HbA1c area percentages
hba1c_data <- data.frame(
  Sample = c("Sample 1", "Sample 1", "Sample 2", "Sample 2", "Sample 3", "Sample 3"),
  A1b = c(3.7, 3.8, 3.7, 3.7, 4.3, 4.3),
  LA1c_CJn1 = c(1.3, 1.3, 1.3, 1.3, 1.1, 1.1),
  A1c = c(5.8, 5.8, 7.3, 6.9, 15.1, 15.0),
  P3 = c(9.9, 10.0, 9.9, 10.1, 7.8, 7.8),
  AO = c(79.2, 79.2, 77.9, 77.9, 71.7, 71.8)
)

# Calculate mean and standard deviation
hba1c_summary <- hba1c_data %>%
  group_by(Sample) %>%
  summarise(across(A1b:AO, list(mean = ~mean(.), sd = ~sd(.)), .names = "mean_{col}"))

# Print the summary table
print(hba1c_summary)

# Plot HbA1c area percentages
hba1c_long <- pivot_longer(hba1c_summary, cols = starts_with("mean"), names_to = "Parameter", values_to = "Value")
hba1c_long <- separate(hba1c_long, Parameter, into = c("Stat", "Parameter"), sep = "_")

ggplot(hba1c_long, aes(x = Parameter, y = Value, fill = Stat)) +
  geom_bar(stat = "identity", position = "dodge") +
  labs(title = "HbA1c Area Percentages", x = "Parameter", y = "Percentage") +
  theme_minimal()
