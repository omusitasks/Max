# Load required libraries
library(fda)

# Load subdatasets
data(iy)
data(sh)

# Select "sh" and "iy" subdatasets
sh_data <- sh$y   # Extract the numeric data from the "sh" subdataset
iy_data <- iy$y   # Extract the numeric data from the "iy" subdataset

# Descriptive Analysis - "sh" Subdataset
# Summary statistics
summary_sh <- summary(sh_data)
print("Summary Statistics for 'sh' Subdataset:")
print(summary_sh)

# Box plot for visualizing distribution
boxplot(sh_data, main = "Box Plot - 'sh' Subdataset")

# Density plot for visualizing distribution
plot(density(sh_data), main = "Density Plot - 'sh' Subdataset")

# No built-in function for spectrogram, you may need to use other packages or custom functions

# Descriptive Analysis - "iy" Subdataset
# Summary statistics
summary_iy <- summary(iy_data)
print("Summary Statistics for 'iy' Subdataset:")
print(summary_iy)

# Box plot for visualizing distribution
boxplot(iy_data, main = "Box Plot - 'iy' Subdataset")

# Density plot for visualizing distribution
plot(density(iy_data), main = "Density Plot - 'iy' Subdataset")

# No built-in function for spectrogram, you may need to use other packages or custom functions

# Exploratory Analysis - "sh" Subdataset
# Principal Component Analysis (PCA)
pca_sh <- prcomp(t(sh_data))  # Transpose the data matrix as PCA expects variables as rows

# Scatter plot of PCA components
plot(pca_sh$x[,1], pca_sh$x[,2], 
     xlab = "PC1", ylab = "PC2", 
     main = "PCA Scatter Plot - 'sh' Subdataset")

# Clustering with k-means
kmeans_sh <- kmeans(sh_data, centers = 3) # Choose appropriate number of clusters
print("Cluster Centers for 'sh' Subdataset:")
print(kmeans_sh$centers)

# Exploratory Analysis - "iy" Subdataset
# Principal Component Analysis (PCA)
pca_iy <- prcomp(t(iy_data))  # Transpose the data matrix as PCA expects variables as rows

# Scatter plot of PCA components
plot(pca_iy$x[,1], pca_iy$x[,2], 
     xlab = "PC1", ylab = "PC2", 
     main = "PCA Scatter Plot - 'iy' Subdataset")

# Clustering with k-means
kmeans_iy <- kmeans(iy_data, centers = 3) # Choose appropriate number of clusters
print("Cluster Centers for 'iy' Subdataset:")
print(kmeans_iy$centers)
