
# set working environmnet
###  setwd("C:/Users/user/Downloads/Mini Project")


# Load necessary libraries
library(readr)   # For reading the dataset
library(glm2)    # For fitting generalized linear models
library(ggplot)
library(caret) # For cross-validation


# load heart disease dataset
# Read the dataset
heart_data <- read.csv("HeartDisease.csv")

# Explore the structure of the dataset
str(heart_data)

# Overview of the dataset
summary(heart_data)

# Check for missing values
sum(is.na(heart_data))

# Check the distribution of the response variable
table(heart_data$TenYearCHD)


# 
# a) Give a general overview of the problem and decide which type of generalized linear model
# is appropriate for studying the kind of data considered here. Justify your answer

# Fit logistic regression model
logit_model <- glm(TenYearCHD ~ Gender + Age + CigsPerDay + Chronic + TotChol + SysBP + DiaBP + BMI + HeartRate + Glucose, data = heart_data, family = binomial)

# Summary of the fitted model
summary(logit_model)



# b) Using appropriate selection techniques, select the simplest best model that fits the data.
# Justify your answer fully

# Define the formula for logistic regression
formula <- TenYearCHD ~ Gender + Age + CigsPerDay + Chronic + TotChol + SysBP + DiaBP + BMI + HeartRate + Glucose

# Fit initial logistic regression model
initial_model <- glm(formula, family = binomial, data = heart_data)

# Let's Perform stepwise variable selection
final_model <- step(initial_model, direction = "both")

# Cross-validation setup
set.seed(123) # for reproducibility
ctrl <- trainControl(method = "cv", number = 10) # 10-fold cross-validation

# Fit models with different combinations of variables
model_cv <- train(formula, data = heart_data, method = "glm", trControl = ctrl, family = binomial, tuneGrid = expand.grid(alpha = 0, lambda = 0))

# Retrieve AIC and BIC values
AIC_values <- AIC(final_model)
BIC_values <- BIC(final_model)

# Find the model with the lowest AIC and BIC
best_AIC_model <- final_model[AIC_values == min(AIC_values)]
best_BIC_model <- final_model[BIC_values == min(BIC_values)]

# Justification for model selection
# Compare AIC and BIC values of the selected models
print(paste("AIC of the best model:", min(AIC_values)))
print(paste("BIC of the best model:", min(BIC_values)))
