#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("Hello world!\n");
    return 0;
}


int foo() {
 for (int x=0; x<5; x++) {
 cout <<"Value of x is " << x << endl;
 return 0;
}
