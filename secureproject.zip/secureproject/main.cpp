#include <iostream>
#include <strsafe.h>
#include <stdexcept>

void sampleFunc(char inStr[]) {
    const int bufferSize = 10;
    char buf[bufferSize];
    HRESULT hr = StringCchCopyN(buf, bufferSize, inStr, bufferSize - 1);
    if (FAILED(hr)) {
        throw std::length_error("Input string exceeds buffer size.");
    }
    std::cout << "\n" << buf << "\n";
    return;
}

int main() {
    try {
        sampleFunc("This is a very long string.");
    } catch (const std::length_error& e) {
        std::cerr << "Exception caught: " << e.what() << std::endl;
    }
    return 0;
}
