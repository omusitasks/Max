import os
import json
import csv
import xml.etree.ElementTree as ET
import pandas as pd
import mysql.connector

# Function to extract data from TXT file
def extract_txt(file_path):
    # Read data from the TXT file
    with open(file_path, 'r') as file:
        data = file.readlines()
    return [{'text': line.strip()} for line in data]  # Convert each line to a dictionary

# Function to extract data from JSON file
def extract_json(file_path):
    # Read data from the JSON file
    with open(file_path, 'r') as file:
        data = json.load(file)
    return data

# Function to extract data from XML file
def extract_xml(file_path):
    # Parse XML file
    tree = ET.parse(file_path)
    root = tree.getroot()

    # Extract data from XML
    data = []
    for elem in root.findall('user'):
        user_data = {}
        for key, value in elem.attrib.items():
            user_data[key] = value
        data.append(user_data)
    return data

# Function to extract data from CSV file
def extract_csv(file_path):
    # Read data from the CSV file
    with open(file_path, 'r') as file:
        reader = csv.DictReader(file)
        data = [{f"{key}_{i}": value for key, value in row.items()} for i, row in enumerate(reader)]
    return data


# Function to transform data into a homogenous record
def transform_data(data):
    # Remove missing values from the dataset
    transformed_data = [item for item in data if all(item.values())]
    return transformed_data

# Function to combine data from different sources into one dataset
def combine_data(txt_data, json_data, xml_data, csv_data):
    # Combine data into one dataset
    combined_data = txt_data + json_data + xml_data + csv_data
    return combined_data

# Function to save combined data into a CSV file
def save_combined_data_to_csv(combined_data, output_file):
    # Convert combined data into a DataFrame
    df = pd.DataFrame(combined_data)

    # Save DataFrame to CSV file
    df.to_csv(output_file, index=False)

# Function to load data into MySQL database
def load_data_into_mysql(csv_file, host, database, user, password):
    # Connect to MySQL database
    connection = mysql.connector.connect(host=host, database=database, user=user, password=password)
    cursor = connection.cursor()

    # Read data from CSV file
    with open(csv_file, 'r') as file:
        reader = csv.DictReader(file)
        header = list(reader.fieldnames)  # Convert fieldnames to a list
        # Generate table name based on CSV filename
        table_name = os.path.splitext(os.path.basename(csv_file))[0]

        # Create table with dynamic table name and columns based on CSV header
        create_table_query = f"CREATE TABLE IF NOT EXISTS `{table_name}` ("
        # Limit the number of columns to 50
        create_table_query += ", ".join([f"`{column}` VARCHAR(255)" for column in header[:50]])
        create_table_query += ")"
        cursor.execute(create_table_query)

        # Insert data into the dynamically created table
        for row in reader:
            # Generate placeholders dynamically based on the length of the row
            placeholders = ', '.join(['%s'] * len(row))
            # Construct the INSERT query with dynamic placeholders
            insert_query = f"INSERT INTO `{table_name}` ({', '.join(header[:50])}) VALUES ({placeholders})"
            # Execute the INSERT query with row values
            cursor.execute(insert_query, list(row.values()))

    # Commit changes and close connection
    connection.commit()
    cursor.close()
    connection.close()



# Main function
def main():
    # Configuration for MySQL connection
    host = 'localhost'
    database = 'etl_pipeline_sme_database'
    user = 'root'
    password = 'password'

    # Extract data from different sources
    txt_data = extract_txt('user_data_23_4.txt')
    json_data = extract_json('user_data_23_4.json')
    xml_data = extract_xml('user_data_23_4.xml')
    csv_data = extract_csv('user_data_23_4.csv')

    # Transform data into a homogenous record
    txt_transformed = transform_data(txt_data)
    json_transformed = transform_data(json_data)
    xml_transformed = transform_data(xml_data)
    csv_transformed = transform_data(csv_data)

    # Combine transformed data from different sources
    combined_data = combine_data(txt_transformed, json_transformed, xml_transformed, csv_transformed)

    # Save combined data into a CSV file
    save_combined_data_to_csv(combined_data, 'combined.csv')

    # Load combined data into MySQL database
    load_data_into_mysql('combined.csv', host, database, user, password)

if __name__ == "__main__":
    main()
