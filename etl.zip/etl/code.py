import csv
import json
import xml.etree.ElementTree as ET
from pony.orm import Database, Required, Json, PrimaryKey, db_session

# Configuration for MySQL connection
host = 'localhost'
database_name = 'etl_pipeline_sme_database'
user = 'root'
password = 'password'

# Define the Pony ORM database
db = Database()

# Bind the database
db.bind(provider='mysql', host=host, database=database_name, user=user, password=password)

# Define a global set to store attributes from all data sources
combined_attributes = set()

# Function to process and load data from text file
def process_text_file(file_path):
    global combined_attributes
    with open(file_path, 'r') as file:
        lines = file.readlines()
        for line in lines:
            attributes = line.strip().split(':')
            combined_attributes.update(attributes)

# Function to process and load data from JSON file
def process_json_file(file_path):
    global combined_attributes
    with open(file_path, 'r') as file:
        data = json.load(file)
        for entry in data:
            combined_attributes.update(entry.keys())

# Function to process and load data from XML file
def process_xml_file(file_path):
    global combined_attributes
    tree = ET.parse(file_path)
    root = tree.getroot()
    for user in root.findall('user'):
        combined_attributes.update(user.attrib.keys())

# Function to process and load data from CSV file
def process_csv_file(file_path):
    global combined_attributes
    with open(file_path, newline='') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            combined_attributes.update(row.keys())

# Define the Pony ORM entity based on combined attributes
class CombinedData(db.Entity):
    id = PrimaryKey(int, auto=True)
    extra_data = Required(Json)
    for attribute in combined_attributes:
        setattr(CombinedData, attribute.replace(' ', '_'), Required(str))

# Main function to orchestrate the ETL process
def main():
    # Process and load data from each file
    process_text_file('user_data_23_4.txt')
    process_json_file('user_data_23_4.json')
    process_xml_file('user_data_23_4.xml')
    process_csv_file('user_data_23_4.csv')

    # Generate mapping and create tables
    db.generate_mapping(create_tables=True)

    # Merge data and write to combined_data.csv
    with db_session:
        with open('combined_data.csv', 'w', newline='') as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=combined_attributes)
            writer.writeheader()
            for obj in CombinedData.select():
                writer.writerow(obj.to_dict())

if __name__ == "__main__":
    main()
