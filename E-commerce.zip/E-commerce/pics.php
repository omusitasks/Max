<?php
 include'header.php';
?>

<div class="container">
    <h5>Landmark Pictures</h5>
<div class="row">
            <div class="col-md-3 col-sm-6 col-6">
              <div class="product-img">
                <img src="img/g3.jpg" width="100%" class="img-fluid">
              </div>
              <div class="product-button">
                <button>Add to cart</button>
              </div>
              <div class="details text-center">
                <h6>The arch of life is simply a great picture!</h6> 
                <span>$235.00</span>               
              </div>
            </div>
            <div class="col-md-3 col-sm-6 col-6">
              <div class="product-img">
                <img src="img/g1.jpg" width="100%" class="img-fluid">
              </div>
              <div class="product-button">
                <button>Add to cart</button>
              </div>
              <div class="details text-center">
                <h6>The arch of life is simply a great picture!</h6> 
                <span>$235.00</span>               
              </div>
            </div>
            <div class="col-md-3 col-sm-6  col-6">
              <div class="product-img">
                <img src="img/g2.jpg" width="100%" class="img-fluid">
              </div>
              <div class="product-button">
                <button>Add to cart</button>
              </div>
              <div class="details text-center">
                <h6>The arch of life is simply a great picture!</h6> 
                <span>$235.00</span>               
              </div>
            </div>
            <div class="col-md-3 col-sm-6 col-6">
              <div class="product-img">
                <img src="img/g4.jpg" width="100%" class="img-fluid">
              </div>
              <div class="product-button">
                <button>Add to cart</button>
              </div>
              <div class="details text-center">
                <h6>The arch of life is simply a great picture!</h6> 
                <span>$235.00</span>               
              </div>
            </div>
            
          </div>
</div>


<?php
 include'footer.php';
?>