# Load necessary libraries
library(ggplot2)

# Data for IL-8 standards
standards <- data.frame(
  concentration = c(0, 15.6, 31.2, 62.5, 125, 250, 500, 1000),
  abs1 = c(0.055, 0.098, 0.130, 0.155, 0.253, 0.420, 0.671, 1.138),
  abs2 = c(0.075, 0.128, 0.159, 0.163, 0.256, 0.427, 0.650, 1.087)
)

# Calculate average absorbance
standards$avg_abs <- rowMeans(standards[, c("abs1", "abs2")])

# Generate standard curve plot
ggplot(standards, aes(x = concentration, y = avg_abs)) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE) +
  labs(title = "IL-8 Standard Curve",
       x = "IL-8 Concentration (pg/ml)",
       y = "Absorbance at 450 nm") +
  theme_minimal()

# Data for unknown samples
unknowns <- data.frame(
  sample = 1:8,
  abs1 = c(0.193, 0.685, 0.188, 1.109, 0.088, 0.411, 1.353, 0.199),
  abs2 = c(0.170, 0.714, 0.152, 0.973, 0.092, 0.430, 1.368, 0.140)
)

# Calculate average absorbance
unknowns$avg_abs <- rowMeans(unknowns[, c("abs1", "abs2")])

# Predict IL-8 concentrations for unknown samples using the standard curve model
model <- lm(avg_abs ~ concentration, data = standards)
unknowns$concentration <- predict(model, newdata = data.frame(concentration = unknowns$avg_abs))

# Generate bar plot for unknown samples' IL-8 concentrations
ggplot(unknowns, aes(x = factor(sample), y = concentration)) +
  geom_bar(stat = "identity") +
  labs(title = "IL-8 Concentrations of Unknown Samples",
       x = "Unknown Sample",
       y = "IL-8 Concentration (pg/ml)") +
  theme_minimal()
