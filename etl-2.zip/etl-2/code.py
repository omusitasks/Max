import os
import json
import csv
import xml.etree.ElementTree as ET
import pandas as pd
from pony.orm import *

# Define Pony ORM database
db = Database()

# Define data models
class CombinedData(db.Entity):
    id = PrimaryKey(int, auto=True)
    text_data = Optional(str, max_len=500)  # Adjusted max length to 500
    json_firstName = Optional(str)
    json_lastName = Optional(str)
    json_age = Optional(int)
    json_iban = Optional(str)
    json_credit_card_number = Optional(str)
    json_credit_card_security_code = Optional(str)
    json_credit_card_start_date = Optional(str)
    json_credit_card_end_date = Optional(str)
    json_address_main = Optional(str)
    json_address_city = Optional(str)
    json_address_postcode = Optional(str)
    xml_firstName = Optional(str)
    xml_lastName = Optional(str)
    xml_age = Optional(int)
    xml_sex = Optional(str)
    csv_First_Name = Optional(str)  # Updated attribute name
    csv_Second_Name = Optional(str)  # Updated attribute name
    csv_Age_Years = Optional(int)   # Updated attribute name
    csv_Sex = Optional(str)         # Updated attribute name
    csv_Vehicle_Make = Optional(str)
    csv_Vehicle_Model = Optional(str)
    csv_Vehicle_Year = Optional(int)
    csv_Vehicle_Type = Optional(str)
    json_debt = Optional(str)  # Added attribute for completeness


# Function to extract data from TXT file
def extract_txt(file_path):
    with open(file_path, 'r') as file:
        data = file.readlines()
    return [{'text_data': line.strip()} for line in data]

# Function to extract data from JSON file
def extract_json(file_path):
    with open(file_path, 'r') as file:
        data = json.load(file)
    if isinstance(data, list):
        return [{'json_' + key: value for key, value in item.items()} for item in data]
    else:
        # Ensure json_debt is a string, set to empty string if not present
        json_debt = str(data.get('json_debt', ''))
        return [{'json_' + key: value for key, value in data.items()}, {'json_debt': json_debt}]


# Function to extract data from XML file
def extract_xml(file_path):
    tree = ET.parse(file_path)
    root = tree.getroot()
    return extract_data_from_xml(root)

# Function to extract data from XML root
def extract_data_from_xml(root):
    data = []
    for elem in root.findall('.//user'):
        user_data = {}
        user_data['xml_firstName'] = elem.attrib.get('firstName', '')
        user_data['xml_lastName'] = elem.attrib.get('lastName', '')
        user_data['xml_age'] = elem.attrib.get('age', '')
        user_data['xml_sex'] = elem.attrib.get('sex', '')
        data.append(user_data)
    return data

# Function to extract data from CSV file
def extract_csv(file_path):
    with open(file_path, 'r') as file:
        reader = csv.DictReader(file)
        data = [{f"csv_{key}": value for key, value in row.items()} for row in reader]
    return data

# Function to preprocess CSV data to match attribute names in the entity
def preprocess_csv_data(csv_data):
    for row in csv_data:
        row['csv_First_Name'] = row.pop('csv_First Name')
        row['csv_Second_Name'] = row.pop('csv_Second Name')
        row['csv_Age_Years'] = row.pop('csv_Age (Years)')
        row['csv_Vehicle_Make'] = row.pop('csv_Vehicle Make')
        row['csv_Vehicle_Model'] = row.pop('csv_Vehicle Model')
        row['csv_Vehicle_Year'] = row.pop('csv_Vehicle Year')
        row['csv_Vehicle_Type'] = row.pop('csv_Vehicle Type')
    return csv_data


# Function to combine data from different sources into one dataset
def combine_data(txt_data, json_data, xml_data, csv_data):
    max_len = max(len(txt_data), len(json_data), len(xml_data), len(csv_data))
    combined_data = []
    for i in range(max_len):
        record = {}
        record.update(txt_data[i % len(txt_data)])
        
        # Extract json_debt from json_data and convert it to a string
        json_debt_record = json_data[i % len(json_data)].pop('json_debt', {})  # Pop json_debt attribute
        json_debt_str = json_debt_record.get('json_debt', '') if isinstance(json_debt_record, dict) else ''
        record.update(json_data[i % len(json_data)])
        record['json_debt'] = json_debt_str  # Add json_debt as a string to record
        
        record.update(xml_data[i % len(xml_data)])
        record.update(csv_data[i % len(csv_data)])
        combined_data.append(record)
    return combined_data



# Function to save combined data to CSV
def save_combined_data_to_csv(combined_data, output_file):
    df = pd.DataFrame(combined_data)
    df.to_csv(output_file, index=False)

# Function to load data into MySQL database using Pony ORM
@db_session
def load_data_into_mysql(combined_data):
    for data in combined_data:
        CombinedData(**data)

# Main function
def main():
    # Connect to the MySQL database
    db.bind(provider='mysql', host='europa.ashley.work', user='student_bi59ij', password='iE93F2@8EhM@1zhD&u9M@K', database='student_bi59ij')
    # db.bind(provider='mysql', host='localhost', user='root', database='data_pipeline_db')
    db.generate_mapping(create_tables=True)

    # Extract data from different sources
    txt_data = extract_txt('user_data_23_4.txt')
    json_data = extract_json('user_data_23_4.json')
    xml_data = extract_xml('user_data_23_4.xml')
    csv_data = extract_csv('user_data_23_4.csv')

    # Preprocess CSV data to match attribute names in the entity
    csv_data = preprocess_csv_data(csv_data)

    # Combine data
    combined_data = combine_data(txt_data, json_data, xml_data, csv_data)

    # Save combined data to CSV
    save_combined_data_to_csv(combined_data, 'combined_data.csv')

    # Load data into MySQL database using Pony ORM
    load_data_into_mysql(combined_data)

if __name__ == "__main__":
    main()
