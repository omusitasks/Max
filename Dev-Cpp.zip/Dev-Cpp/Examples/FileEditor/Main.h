
#define CM_FILE_SAVEAS	9072
#define CM_FILE_EXIT	9071
#define CM_FILE_OPEN	9070
#define CM_ABOUT        9069

